#!/bin/bash

echo "Xenon-noc setup started"
sleep 2
echo "Mysql release start"
helm upgrade --install mysql Noc-helm-charts/mysql/ -n xenon-noc
echo "Mysql release completed successfully."
sleep 20
echo "Blackbox release start"
helm upgrade --install prometheus-blackbox ./Noc-helm-charts/prometheus-blackbox-exporter/ -f ./Noc-helm-charts/blackbox-exporter/black-values.yaml -n xenon-noc
echo "Blackbox release completed successfully."
echo "Please be sure you have added jira api keys and url in the Jira pod deployment manifest file."
sleep 10
echo "Jira pod creaton start"
kubectl apply -f Jira/
echo "Jira configuration has been completed successfully"
echo "grafana release start"
helm upgrade --install grafana ./Noc-helm-charts/kube-prometheus-stack/ -f ./Noc-helm-charts/blackbox-exporter/grafana-values.yaml -n xenon-noc
echo "grafana release completed successfully."
echo "Loki release start"
helm upgrade --install loki ./Noc-helm-charts/loki/ -f ./Noc-helm-charts/loki/values.yaml -n xenon-noc
echo "Loki release completed successfully."
sleep 40
echo "promtail release start"
helm upgrade --install promtail ./Noc-helm-charts/promtail/ -f ./Noc-helm-charts/promtail/values.yaml -n xenon-noc
echo "Promtail release completed successfully."



echo " Configuration setup start. Please Hang on!!"

cd IAC/
terraform init
terraform plan 
terraform apply -auto-approve


echo " Yay !!Setup completed!!"
