# Xenonstack NOC

In this noc we have deployed grafana prometheus for end to end sites and data visualization and trigger alerts to the microsoft teams and creating tickets on jira




## Installation Guide
Follow the below steps to deploy the softwares and setup the configuration through IAC.
### Quick Installation
Run ```./setup.sh ``` from the project repository for One Click Installation. 
### Pre-requisites
#### Helm charts
We will require following helm charts:
 - Kube prometheus stack
 - prometheus blackbox exporter
 - mysql (For the backend setup)
 - loki 
 - promtail
#### Jira alert
We'll configure our own custom webhook to send alerts to jira for creating jira tickets on basis of firing alerts
 - Add api_url, user, password, project-key for your jira account in secret.yaml file
 - ``` kubectl apply -f Jira/ ```
#### IAC
We will be using terraform as our IAC tool which requires:
 - grafana plugin 
 - Dashboards json
 - grafana server service account token
 - datasource urls
 - contact point and notification template

## Installation:
Installation will be divided in two parts:
 - Grafana ui setup
 - Grafana configuration Setup
# Grafana ui setup
### Step 1: Clone the repo
``` git clone https://git.neuralcompany.team/cloudops/noc/ ```

### Step 2: Checkout to feature branch
``` git checkout feature ```
### Step 3: Install Mysql
From the repo directory run:

``` helm upgrade --install mysql Noc-helm-charts/mysql/ -n xenon-noc ```

### Step 4: Install Blackbox exporter:
Now, Install blackbox exporter to probe the external targets. From the project directory run:

``` helm upgrade --install prometheus-blackbox ./Noc-helm-charts/prometheus-blackbox-exporter/ -f ./Noc-helm-charts/blackbox-exporter/black-values.yaml-n xenon-noc ```

### Step 5: Install the Kube Prometheus Stack:

Configure your values.yaml to send alerts to jira
 - Create custom rules under ```additionalPrometheusRulesMap``` to define alerting rules
 - Configure ``` alertmanager ``` to send jira alerts

Go to the project directory and run:

``` helm upgrade --install grafana ./Noc-helm-charts/kube-prometheus-stack/ -f ./Noc-helm-charts/blackbox-exporter/grafana-values.yaml -n xenon-noc ```

After all the pods are up and running, you can access grafana UI at ``` https://grafana.neuralcompany.team ```.

### Step 6: Install the Loki:

 - Configure values.yaml set type. of. storage you need to use to store under ``storage`` and  configure ```querier``` and ``` query_scheduler``` according to your need.
 - Install the helm charts ``` helm install loki ./Noc-helm-charts/loki/ -f ./Noc-helm-charts/loki/values.yaml -n xenon-noc```

### Step 7: Install Promtail:

 - Add url of your loki instance under ``clients.url`` in values.yaml file
 - Install the helm charts ``` helm install promtail ./Noc-helm-charts/promtail/ -f ./Noc-helm-charts/promtail/values.yaml -n xenon-noc```



# Grafana Configuration Setup:

### Step 1. Get the Service Account Token
 - Login to grafana UI with admin account and go to ``` Administration -> service account ``` and create a service account and generate a access token for it.

### Step 2. Initialize terraform

From the project directory go inside the ``` noc/IAC/ ``` directory and run
``` terraform init ```.
### Step 3. Create Execution plan
Run ```terraform plan``` command to create an execution plan.

### Step 4. Apply the plan

Run ``` terraform apply ``` command which will prompt you for your grafana service account access token and the external datasource url.

-----------------------------------------------------------------------------------

That's it, After terraform apply runs successfully your infrastructure will be setup within a minute.

